package com.innovationnest.briancoder.travelschedulesug.domain.usecase

import com.innovationnest.briancoder.travelschedulesug.domain.service.ContextDataService
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.SaveAccessTokenUseCase
import com.innovationnest.briancoder.travelschedulesug.extensions.ImmediateSchedulerRuleUnitTests
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsSuccess
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherSuccess
import com.nhaarman.mockito_kotlin.any
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.whenever
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class SaveAccessTokenUseCaseTest {

    private lateinit var saveAccessTokenUseCase: SaveAccessTokenUseCase

    @JvmField
    @Rule
    val immediateSchedulerRule = ImmediateSchedulerRuleUnitTests()
    @Mock
    private lateinit var contextDataService: ContextDataService

    @Before
    fun setUp() {
        saveAccessTokenUseCase = SaveAccessTokenUseCase(contextDataService)
    }

    @Test
    fun `invoke should return access token`() {
        val accessToken = "d3ukap6h6ym9pchzf3ax6nga"
        whenever(contextDataService.saveAccessToken(any())).doReturn(getObEitherSuccess(accessToken))

        val testObserver = saveAccessTokenUseCase(accessToken).test().await()

        testObserver.assertGeneralsSuccess { it == accessToken }
    }

}