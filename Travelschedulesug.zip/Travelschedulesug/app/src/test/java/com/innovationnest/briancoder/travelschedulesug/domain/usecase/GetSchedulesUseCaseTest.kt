package com.innovationnest.briancoder.travelschedulesug.domain.usecase

import com.innovationnest.briancoder.travelschedulesug.domain.model.getScheduleList
import com.innovationnest.briancoder.travelschedulesug.domain.repository.ScheduleRepository
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.schedule.GetSchedulesUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.schedule.GetSchedulesUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.extensions.ImmediateSchedulerRuleUnitTests
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsError
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsSuccess
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherError
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherSuccess
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.whenever
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyInt
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class GetSchedulesUseCaseTest {

    private lateinit var getSchedulesUseCase: GetSchedulesUseCase

    @JvmField
    @Rule
    val immediateSchedulerRule = ImmediateSchedulerRuleUnitTests()
    @Mock
    private lateinit var scheduleRepository: ScheduleRepository

    @Before
    fun setUp() {
        getSchedulesUseCase = GetSchedulesUseCase(scheduleRepository)
    }

    @Test
    fun `invoke should return flight list`() {
        whenever(scheduleRepository.getSchedules(
                anyString(),
                anyString(),
                anyString(),
                anyInt(),
                anyInt()
        )).doReturn(getObEitherSuccess(getScheduleList()))

        val testObserver = getSchedulesUseCase(
                Params("", "", 0, 0, "")
        ).test().await()

        testObserver.assertGeneralsSuccess { it.isNotEmpty() }
    }

    @Test
    fun `invoke should return failure`() {
        whenever(scheduleRepository.getSchedules(
                anyString(),
                anyString(),
                anyString(),
                anyInt(),
                anyInt()
        )).doReturn(getObEitherError())

        val testObserver = getSchedulesUseCase(
                Params("", "", 0, 0, "")
        ).test().await()

        testObserver.assertGeneralsError()
    }

}