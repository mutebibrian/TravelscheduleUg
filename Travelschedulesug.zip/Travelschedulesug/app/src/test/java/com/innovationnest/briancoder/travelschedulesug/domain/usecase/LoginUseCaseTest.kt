package com.innovationnest.briancoder.travelschedulesug.domain.usecase

import com.innovationnest.briancoder.travelschedulesug.domain.repository.LoginRepository
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.LoginUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.LoginUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.SaveAccessTokenUseCase
import com.innovationnest.briancoder.travelschedulesug.extensions.ImmediateSchedulerRuleUnitTests
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsError
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsSuccess
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherError
import com.innovationnest.briancoder.travelschedulesug.extensions.getObEitherSuccess
import com.nhaarman.mockito_kotlin.any
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.whenever
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class LoginUseCaseTest {

    private lateinit var loginUseCase: LoginUseCase

    @JvmField
    @Rule
    val immediateSchedulerRule = ImmediateSchedulerRuleUnitTests()
    @Mock
    private lateinit var loginRepository: LoginRepository
    @Mock
    private lateinit var saveAccessTokenUseCase: SaveAccessTokenUseCase

    @Before
    fun setUp() {
        loginUseCase = LoginUseCase(loginRepository, saveAccessTokenUseCase)
    }

    @Test
    fun `invoke should return access token`() {
        val accessToken = "d3ukap6h6ym9pchzf3ax6nga"
        whenever(loginRepository.login(any(), any())).doReturn(getObEitherSuccess(accessToken))
        whenever(saveAccessTokenUseCase(any())).doReturn(getObEitherSuccess(accessToken))

        val testObserver = loginUseCase(Params("", "")).test().await()

        testObserver.assertGeneralsSuccess { it == accessToken }
    }

    @Test
    fun `invoke should return failure`() {
        whenever(loginRepository.login(any(), any())).doReturn(getObEitherError())
        whenever(saveAccessTokenUseCase(any())).doReturn(getObEitherError())

        val testObserver = loginUseCase(Params("", "")).test().await()

        testObserver.assertGeneralsError()
    }

}