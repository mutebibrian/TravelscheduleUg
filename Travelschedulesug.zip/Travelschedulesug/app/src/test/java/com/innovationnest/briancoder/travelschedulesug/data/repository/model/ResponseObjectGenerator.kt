package com.innovationnest.briancoder.travelschedulesug.data.repository.model

import com.innovationnest.briancoder.travelschedulesug.Airport
import com.innovationnest.briancoder.travelschedulesug.data.entity.airport.AirportResponse
import com.innovationnest.briancoder.travelschedulesug.data.entity.airport.AirportResponse.AirportResource
import com.innovationnest.briancoder.travelschedulesug.data.entity.airport.AirportResponse.AirportResource.Airports
import com.innovationnest.briancoder.travelschedulesug.data.entity.airport.AirportResponse.AirportResource.Airports.Airport
import com.innovationnest.briancoder.travelschedulesug.data.entity.schedule.ScheduleResponse
import com.innovationnest.briancoder.travelschedulesug.data.entity.schedule.ScheduleResponse.ScheduleResource
import com.innovationnest.briancoder.travelschedulesug.data.entity.schedule.ScheduleResponse.ScheduleResource.Schedule
import com.innovationnest.briancoder.travelschedulesug.data.entity.schedule.ScheduleResponse.ScheduleResource.Schedule.Flight
import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule

fun getScheduleResponse(): ScheduleResponse =
        ScheduleResponse(ScheduleResource(listOf(Schedule(flightList = listOf(Schedule.Flight())))))

fun getAirportResponse(): AirportResponse =
        AirportResponse(AirportResource(Airports(listOf(Airport()))))