package com.innovationnest.briancoder.travelschedulesug.data.repository

import com.innovationnest.briancoder.travelschedulesug.data.net.ScheduleApiClient
import com.innovationnest.briancoder.travelschedulesug.data.repository.datasources.api.schedules.ScheduleApi
import com.innovationnest.briancoder.travelschedulesug.data.repository.implementation.api.ScheduleRepositoryImpl
import com.innovationnest.briancoder.travelschedulesug.data.repository.model.getScheduleResponse
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsError
import com.innovationnest.briancoder.travelschedulesug.extensions.assertGeneralsSuccess
import com.innovationnest.briancoder.travelschedulesug.extensions.getObResultError
import com.innovationnest.briancoder.travelschedulesug.extensions.getObResultSuccess
import com.nhaarman.mockito_kotlin.doReturn
import com.nhaarman.mockito_kotlin.whenever
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mock
import org.mockito.Mockito.anyInt
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class ScheduleRepositoryImplTest {

    private lateinit var scheduleRepositoryImpl: ScheduleRepositoryImpl

    @Mock
    private lateinit var scheduleApiClient: ScheduleApiClient
    @Mock
    private lateinit var scheduleApi: ScheduleApi

    @Before
    fun setUp() {
        whenever(scheduleApiClient.api).then { scheduleApi }

        scheduleRepositoryImpl = ScheduleRepositoryImpl(scheduleApiClient)
    }

    @Test
    fun `get schedules should return flight list`() {
        whenever(scheduleApi.getSchedules(
                anyString(),
                anyString(),
                anyString(),
                anyInt(),
                anyInt(),
                anyString()
        )).doReturn(getObResultSuccess(getScheduleResponse()))

        val testObserver = scheduleRepositoryImpl.getSchedules(
                "",
                "",
                "",
                0,
                0
        ).test()

        testObserver.assertGeneralsSuccess { it.isNotEmpty() }
    }

    @Test
    fun `get schedules should return failure error`() {
        whenever(scheduleApi.getSchedules(
                anyString(),
                anyString(),
                anyString(),
                anyInt(),
                anyInt(),
                anyString()
        )).doReturn(getObResultError())

        val testObserver = scheduleRepositoryImpl.getSchedules(
                "",
                "",
                "",
                0,
                0
        ).test()

        testObserver.assertGeneralsError()
    }

}