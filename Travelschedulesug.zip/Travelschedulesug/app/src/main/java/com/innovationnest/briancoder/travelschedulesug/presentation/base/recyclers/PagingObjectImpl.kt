package ccom.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers

import com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers.PagingObject
import com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers.PagingObject.ItemViewType.ITEM

class PagingObjectImpl : PagingObject {

    override var itemViewType = ITEM

}