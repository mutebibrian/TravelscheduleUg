package com.innovationnest.briancoder.travelschedulesug.presentation.schedulelist


import androidx.annotation.StringRes
import com.innovationnest.briancoder.travelschedulesug.Airport

import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule
import com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers.PagingView



interface ScheduleListView : PagingView<Schedule> {

    fun goToMap(departureAirport: Airport, arrivalAirport: Airport)

    fun showErrorConfigurationImage(@StringRes title: Int)

    fun hideErrorConfigurationImage()

}