package com.innovationnest.briancoder.travelschedulesug.domain.model.base

interface ResponseObject<out DomainObject : Any> {

    fun toAppDomain(): DomainObject

}