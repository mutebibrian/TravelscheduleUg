package com.innovationnest.briancoder.travelschedulesug.infrastructure.di.module

import com.innovationnest.briancoder.travelschedulesug.data.service.ContextDataServiceImpl
import com.innovationnest.briancoder.travelschedulesug.domain.service.ContextDataService
import dagger.Binds
import dagger.Module

@Module
abstract class ServiceModule {

    @Binds
    abstract fun contextDataService(contextDataServiceImpl: ContextDataServiceImpl): ContextDataService

}