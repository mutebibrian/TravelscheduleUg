package com.innovationnest.briancoder.travelschedulesug.infrastructure.di.component

import com.innovationnest.briancoder.travelschedulesug.domain.repository.LoginRepository
import com.innovationnest.briancoder.travelschedulesug.infrastructure.FlightsApp
import com.innovationnest.briancoder.travelschedulesug.infrastructure.di.module.ActivityModule
import com.innovationnest.briancoder.travelschedulesug.infrastructure.di.module.RepositoryModule
import com.innovationnest.briancoder.travelschedulesug.infrastructure.di.module.ServiceModule
import com.innovationnest.briancoder.travelschedulesug.presentation.schedulelist.ScheduleListPresenter
import com.innovationnest.briancoder.travelschedulesug.presentation.selectairport.AirportListPresenter
import com.innovationnest.briancoder.travelschedulesug.presentation.splash.SplashPresenter
import dagger.Component
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton

@Singleton
@Component(modules = [
    AndroidSupportInjectionModule::class,
    ActivityModule::class,
    RepositoryModule::class,
    ServiceModule::class
])
interface AppComponent : AndroidInjector<FlightsApp> {

    fun provideLoginRepository(): LoginRepository

    fun provideSplashPresenter(): SplashPresenter

    fun provideSchedulesListPresenter(): ScheduleListPresenter

    fun provideAirportsListPresenter(): AirportListPresenter

}