package com.innovationnest.briancoder.travelschedulesug.infrastructure

import com.innovationnest.briancoder.travelschedulesug.infrastructure.di.component.DaggerAppComponent
import dagger.android.AndroidInjector
import dagger.android.support.DaggerApplication

class FlightsApp : DaggerApplication() {

    override fun applicationInjector(): AndroidInjector<out DaggerApplication> =
            DaggerAppComponent.create()

}