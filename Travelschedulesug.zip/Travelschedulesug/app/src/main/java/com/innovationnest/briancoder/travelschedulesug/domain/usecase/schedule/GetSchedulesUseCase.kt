package com.innovationnest.briancoder.travelschedulesug.domain.usecase.schedule

import com.innovationnest.briancoder.travelschedulesug.domain.model.schedule.Schedule
import com.innovationnest.briancoder.travelschedulesug.domain.repository.ScheduleRepository
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.airport.GetAirportsUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.base.UseCase
import com.innovationnest.briancoder.travelschedulesug.subObs
import com.innovationnest.briancoder.travelschedulesug.format

import java.util.Calendar
import javax.inject.Inject

class GetSchedulesUseCase @Inject constructor(
        private val scheduleRepository: ScheduleRepository
) : UseCase<List<Schedule>, GetAirportsUseCase.Params> {

    override fun invoke(params: GetAirportsUseCase.Params) =
            scheduleRepository.getSchedules(
                    params.origin,
                    params.destination,
                    params.fromDateTime,
                    params.limit,
                    params.offset
            ).subObs()

    class Params(val origin: String,
                 val destination: String,
                 val limit: Int = 10,
                 val offset: Int,
                 val fromDateTime: String = Calendar.getInstance().time.format())

}