package com.innovationnest.briancoder.travelschedulesug.domain.model.base

class CallInfo(
        val code: Int,
        var message: String
)