package com.innovationnest.briancoder.travelschedulesug.presentation.base

import com.google.android.material.snackbar.Snackbar.LENGTH_LONG

interface View {

    fun showToast(message: String, resId: Int = -1)

    fun showSnackbarWithRes(@android.support.annotation.StringRes title: Int, @androidx.annotation.StringRes action: Int = android.R.string.ok, length: Int = LENGTH_LONG, actionResult: () -> Unit = {})

    fun showSnackbar(title: String, action: String = "Ok", length: Int = LENGTH_LONG, actionResult: () -> Unit = {})

}