package com.innovationnest.briancoder.travelschedulesug.presentation.schedulelist

import com.innovationnest.briancoder.travelschedulesug.Airport
import com.innovationnest.briancoder.travelschedulesug.R
import com.innovationnest.briancoder.travelschedulesug.check
import com.innovationnest.briancoder.travelschedulesug.domain.extensions.check
import com.innovationnest.briancoder.travelschedulesug.domain.extensions.safeLet
import com.innovationnest.briancoder.travelschedulesug.domain.model.airport.Airport
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure.NoMoreData
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.schedule.GetSchedulesUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.schedule.GetSchedulesUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.presentation.base.Presenter
import javax.inject.Inject

class ScheduleListPresenter @Inject constructor(
        private val getSchedulesUseCase: GetSchedulesUseCase
) : Presenter<ScheduleListView>() {

    private var defaultOffset = 10

    var departureAirport: Airport? = null
    var arrivalAirport: Airport? = null

    fun getSchedulesPage(page: Int, isRefreshingList: Boolean = false) {
        checkAirportsAndExecute { departure, arrival ->
            view?.hideErrorConfigurationImage()

            val offset = page * defaultOffset
            val isFirstPage = offset == 0

            addSubscription(getSchedulesUseCase(Params(departure.airportCode, arrival.airportCode, defaultOffset, offset)).subscribe { either ->
                either.check(
                        { onGetPageFailure(it, isFirstPage) },
                        { view?.onLoadPageSuccess(it, isRefreshingList) }
                )
            })
        }
    }

    fun checkAirportsAndGoToMap() {
        checkAirportsAndExecute { departure, arrival ->
            view?.goToMap(departure, arrival)
        }
    }

    private fun onGetPageFailure(failure: Failure, isFirstPage: Boolean) {
        when (failure) {
            is NoMoreData -> view?.onFinishList()
            else -> {
                view?.onLoadPageError(isFirstPage)
                view?.showSnackbar(failure.callInfo.message)
            }
        }
    }

    private fun checkAirportsAndExecute(execute: (Airport, Airport) -> Unit) {
        safeLet(departureAirport, arrivalAirport) { departure, arrival ->
            if (departure.airportCode != arrival.airportCode) {
                execute(departure, arrival)
            } else {
                view?.showErrorConfigurationImage(R.string.choose_different_airports)
            }
        } ?: view?.showErrorConfigurationImage(R.string.choose_airports)
    }

}