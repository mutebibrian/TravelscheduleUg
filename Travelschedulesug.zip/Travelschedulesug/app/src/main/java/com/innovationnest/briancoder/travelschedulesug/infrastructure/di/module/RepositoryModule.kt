package com.innovationnest.briancoder.travelschedulesug.infrastructure.di.module

import com.innovationnest.briancoder.travelschedulesug.domain.repository.LoginRepository
import com.innovationnest.briancoder.travelschedulesug.data.repository.implementation.api.AirportRepositoryImpl
import com.innovationnest.briancoder.travelschedulesug.data.repository.implementation.api.LoginRepositoryImpl
import com.innovationnest.briancoder.travelschedulesug.data.repository.implementation.api.ScheduleRepositoryImpl
import com.innovationnest.briancoder.travelschedulesug.domain.repository.AirportRepository
import com.innovationnest.briancoder.travelschedulesug.domain.repository.ScheduleRepository
import dagger.Binds
import dagger.Module

@Module
abstract class RepositoryModule {

    @Binds
    abstract fun loginRepository(loginRepositoryImpl: LoginRepositoryImpl): LoginRepository

    @Binds
    abstract fun scheduleRepository(scheduleRepositoryImpl: ScheduleRepositoryImpl): ScheduleRepository

    @Binds
    abstract fun airportRepository(airportRepositoryImpl: AirportRepositoryImpl): AirportRepository

}