package com.innovationnest.briancoder.travelschedulesug.infrastructure.di.module

import com.innovationnest.briancoder.travelschedulesug.infrastructure.di.scope.ViewScope
import com.innovationnest.briancoder.travelschedulesug.presentation.schedulelist.ScheduleListActivity
import com.innovationnest.briancoder.travelschedulesug.presentation.selectairport.AirportListActivity
import com.innovationnest.briancoder.travelschedulesug.presentation.splash.SplashActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityModule {

    @ViewScope
    @ContributesAndroidInjector
    abstract fun splashActivityInjector(): SplashActivity

    @ViewScope
    @ContributesAndroidInjector
    abstract fun schedulesListActivityInjector(): ScheduleListActivity

    @ViewScope
    @ContributesAndroidInjector
    abstract fun airportsListActivityInjector(): AirportListActivity

}