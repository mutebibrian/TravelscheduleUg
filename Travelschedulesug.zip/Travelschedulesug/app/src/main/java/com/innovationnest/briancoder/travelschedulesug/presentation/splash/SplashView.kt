package com.innovationnest.briancoder.travelschedulesug.presentation.splash

import com.innovationnest.briancoder.travelschedulesug.presentation.base.View

interface SplashView : View {

    fun onLoginSuccess()

    fun onLoginError()

}