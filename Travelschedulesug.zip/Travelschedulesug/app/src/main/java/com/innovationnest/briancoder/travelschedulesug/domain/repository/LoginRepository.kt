package com.innovationnest.briancoder.travelschedulesug.domain.repository

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import io.reactivex.Observable

interface LoginRepository {

    fun login(clientId: String, clientSecret: String): Observable<Either<Failure, String>>

}