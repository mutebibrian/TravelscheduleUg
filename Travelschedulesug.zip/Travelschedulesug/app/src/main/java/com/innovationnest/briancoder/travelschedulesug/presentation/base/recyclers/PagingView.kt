package com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers

import com.innovationnest.briancoder.travelschedulesug.presentation.base.View

interface PagingView<T : PagingObject> : View {

    fun onLoadPageSuccess(list: List<T>, isRefreshingList: Boolean)

    fun onLoadPageError(isFirstPage: Boolean)

    fun onFinishList()

}