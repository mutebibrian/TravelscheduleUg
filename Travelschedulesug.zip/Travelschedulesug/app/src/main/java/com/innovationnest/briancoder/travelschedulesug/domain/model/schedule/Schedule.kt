package com.innovationnest.briancoder.travelschedulesug.domain.model.schedule

import com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers.PagingObject
import com.innovationnest.briancoder.travelschedulesug.presentation.base.recyclers.PagingObject.ItemViewType.ITEM
import java.util.Date

class Schedule(
        val flightList: List<Flight>,
        val totalDuration: String
) : PagingObject {

    override var itemViewType = ITEM

    class Flight(
            val departure: City,
            val arrival: City,
            val details: Details
    )

    class City(
            val airportCode: String,
            val scheduledTimeLocal: Date
    )

    class Details(
            val flightNumber: String,
            val stopQuantity: Int,
            val daysOfOperation: Int
    )

}