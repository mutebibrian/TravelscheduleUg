package com.innovationnest.briancoder.travelschedulesug.domain.usecase.login

import arrow.core.Either
import com.innovationnest.briancoder.travelschedulesug.domain.service.ContextDataService
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.base.UseCase
import com.innovationnest.briancoder.travelschedulesug.domain.model.base.Failure
import io.reactivex.Observable
import javax.inject.Inject

class SaveAccessTokenUseCase @Inject constructor(
        private val contextDataService: ContextDataService
) : UseCase<String, String> {

    override fun invoke(params: String): Observable<Either<Failure, String>> =
            contextDataService.saveAccessToken(params)

}