package com.innovationnest.briancoder.travelschedulesug.presentation.splash

import com.innovationnest.briancoder.travelschedulesug.BuildConfig.CLIENT_ID
import com.innovationnest.briancoder.travelschedulesug.BuildConfig.CLIENT_SECRET
import com.innovationnest.briancoder.travelschedulesug.domain.extensions.check
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.LoginUseCase
import com.innovationnest.briancoder.travelschedulesug.domain.usecase.login.LoginUseCase.Params
import com.innovationnest.briancoder.travelschedulesug.presentation.base.Presenter
import javax.inject.Inject

class SplashPresenter @Inject constructor(
        private val loginUseCase: LoginUseCase
) : Presenter<SplashView>() {

    fun login(
            clientId: String = CLIENT_ID,
            clientSecret: String = CLIENT_SECRET
    ) {
        addSubscription(loginUseCase(Params(clientId, clientSecret)).subscribe { either ->
            either.check(
                    { view?.onLoginError() },
                    { view?.onLoginSuccess() }
            )
        })
    }

}